# -*- coding: utf-8 -*-
"""Genera la presentación PowerPoint del ejercicio myowndeepl."""
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE

# ---------- Tema (estilo DeepL) ----------
NAVY = RGBColor(0x0F, 0x2B, 0x46)
CYAN = RGBColor(0x00, 0xA9, 0xE0)
LIGHT = RGBColor(0xF4, 0xF6, 0xF8)
GRAY = RGBColor(0x5A, 0x6B, 0x7B)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
DARK = RGBColor(0x1A, 0x1A, 0x1A)
GREEN = RGBColor(0x1E, 0x8E, 0x3E)
RED = RGBColor(0xC5, 0x22, 0x1F)

FONT = "Segoe UI"
MONO = "Consolas"

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
BLANK = prs.slide_layouts[6]
W = prs.slide_width
H = prs.slide_height


# ---------- Helpers ----------
def _bg(slide, color):
    slide.background.fill.solid()
    slide.background.fill.fore_color.rgb = color


def _box(slide, l, t, w, h):
    tb = slide.shapes.add_textbox(l, t, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    return tb, tf


def _para(tf, text, size, color=DARK, bold=False, align=PP_ALIGN.LEFT,
          font=FONT, space_after=6, first=False, italic=False, bullet=False):
    p = tf.paragraphs[0] if first and not tf.paragraphs[0].runs else tf.add_paragraph()
    p.alignment = align
    p.space_after = Pt(space_after)
    r = p.add_run()
    r.text = text
    r.font.size = Pt(size)
    r.font.color.rgb = color
    r.font.bold = bold
    r.font.italic = italic
    r.font.name = font
    return p


def _bar(slide, l, t, w, h, color):
    sh = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, l, t, w, h)
    sh.fill.solid()
    sh.fill.fore_color.rgb = color
    sh.line.fill.background()
    sh.shadow.inherit = False
    return sh


def _card(slide, l, t, w, h, fill=LIGHT, line=CYAN):
    sh = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, l, t, w, h)
    sh.adjustments[0] = 0.06
    sh.fill.solid()
    sh.fill.fore_color.rgb = fill
    sh.line.color.rgb = line
    sh.line.width = Pt(1.5)
    sh.shadow.inherit = False
    return sh


def title_slide():
    s = prs.slides.add_slide(BLANK)
    _bg(s, NAVY)
    _bar(s, 0, Inches(2.4), W, Inches(0.06), CYAN)
    tb, tf = _box(s, Inches(0.9), Inches(2.6), W - Inches(1.8), Inches(1.6))
    _para(tf, "Construyendo un Traductor con Agentes de IA", 40, WHITE, bold=True, first=True, space_after=4)
    _para(tf, "Pipeline  →  Mono-agente  →  Multi-agente", 26, CYAN, bold=True, space_after=12)
    tb2, tf2 = _box(s, Inches(0.9), Inches(4.4), W - Inches(1.8), Inches(2.0))
    _para(tf2, "Proyecto: myowndeepl — traductor tipo DeepL 100% local con Ollama", 18, WHITE, first=True, space_after=4)
    _para(tf2, "Python · FastAPI · Ollama (qwen2.5:7b) · Streamlit · HTTPX", 15, RGBColor(0xBF, 0xD4, 0xE6), space_after=2)


def section(title, subtitle, number):
    s = prs.slides.add_slide(BLANK)
    _bg(s, NAVY)
    _bar(s, 0, Inches(2.8), W, Inches(0.06), CYAN)
    tb, tf = _box(s, Inches(0.9), Inches(3.0), W - Inches(1.8), Inches(1.4))
    _para(tf, f"VERSIÓN {number}", 16, CYAN, bold=True, first=True, space_after=6)
    _para(tf, title, 36, WHITE, bold=True, space_after=8)
    _para(tf, subtitle, 18, RGBColor(0xBF, 0xD4, 0xE6))


def bullets(title, items, kicker=None):
    s = prs.slides.add_slide(BLANK)
    _bg(s, WHITE)
    _bar(s, 0, 0, Inches(0.25), H, CYAN)
    tb, tf = _box(s, Inches(0.8), Inches(0.5), W - Inches(1.6), Inches(0.9))
    if kicker:
        _para(tf, kicker, 13, CYAN, bold=True, first=True, space_after=2)
        _para(tf, title, 28, NAVY, bold=True, space_after=0)
    else:
        _para(tf, title, 28, NAVY, bold=True, first=True, space_after=0)
    tb2, tf2 = _box(s, Inches(0.8), Inches(1.6), W - Inches(1.6), H - Inches(2.2))
    for i, it in enumerate(items):
        if isinstance(it, tuple):
            text, lvl = it
        else:
            text, lvl = it, 0
        p = tf2.paragraphs[0] if i == 0 else tf2.add_paragraph()
        p.space_after = Pt(10)
        if lvl == 0:
            p.text = "▪  " + text
            p.runs[0].font.size = Pt(18)
            p.runs[0].font.color.rgb = DARK
            p.runs[0].font.name = FONT
        else:
            p.text = "     –  " + text
            p.runs[0].font.size = Pt(16)
            p.runs[0].font.color.rgb = GRAY
            p.runs[0].font.name = FONT
    return s


def code_slide(title, code, caption=None, kicker=None):
    s = prs.slides.add_slide(BLANK)
    _bg(s, WHITE)
    _bar(s, 0, 0, Inches(0.25), H, CYAN)
    tb, tf = _box(s, Inches(0.8), Inches(0.4), W - Inches(1.6), Inches(0.9))
    if kicker:
        _para(tf, kicker, 13, CYAN, bold=True, first=True, space_after=2)
        _para(tf, title, 26, NAVY, bold=True, space_after=0)
    else:
        _para(tf, title, 26, NAVY, bold=True, first=True, space_after=0)
    # panel de código
    panel = _card(s, Inches(0.8), Inches(1.45), W - Inches(1.6), Inches(5.4), fill=NAVY, line=CYAN)
    ctf = panel.text_frame
    ctf.word_wrap = True
    ctf.margin_left = Inches(0.35)
    ctf.margin_right = Inches(0.35)
    ctf.margin_top = Inches(0.25)
    lines = code.split("\n")
    for i, ln in enumerate(lines):
        p = ctf.paragraphs[0] if i == 0 else ctf.add_paragraph()
        p.space_after = Pt(2)
        r = p.add_run()
        r.text = ln if ln else " "
        r.font.name = MONO
        r.font.size = Pt(15 if len(code) < 900 else 13)
        if ln.strip().startswith("#"):
            r.font.color.rgb = RGBColor(0x6A, 0x99, 0x55)
        else:
            r.font.color.rgb = RGBColor(0xE8, 0xEE, 0xF4)
    if caption:
        tb2, tf2 = _box(s, Inches(0.8), Inches(6.95), W - Inches(1.6), Inches(0.5))
        _para(tf2, caption, 13, GRAY, italic=True, first=True)
    return s


def flow_slide(title, steps, kicker=None):
    s = prs.slides.add_slide(BLANK)
    _bg(s, WHITE)
    _bar(s, 0, 0, Inches(0.25), H, CYAN)
    tb, tf = _box(s, Inches(0.8), Inches(0.4), W - Inches(1.6), Inches(0.9))
    if kicker:
        _para(tf, kicker, 13, CYAN, bold=True, first=True, space_after=2)
        _para(tf, title, 28, NAVY, bold=True, space_after=0)
    else:
        _para(tf, title, 28, NAVY, bold=True, first=True, space_after=0)
    n = len(steps)
    total_w = Inches(11.0)
    gap = Inches(0.35)
    box_w = (total_w - gap * (n - 1)) / n
    top = Inches(2.3)
    x = Inches(0.9)
    for i, (label, desc) in enumerate(steps):
        _card(s, x, top, box_w, Inches(2.6), fill=NAVY if i == 0 else LIGHT, line=CYAN)
        tb2, tf2 = _box(s, x + Inches(0.15), top + Inches(0.25), box_w - Inches(0.3), Inches(2.2))
        _para(tf2, f"{i+1}", 15, CYAN, bold=True, first=True, space_after=4)
        _para(tf2, label, 16, WHITE if i == 0 else NAVY, bold=True, space_after=6)
        _para(tf2, desc, 12.5, WHITE if i == 0 else GRAY, space_after=0)
        if i < n - 1:
            ar, artf = _box(s, x + box_w + Inches(0.02), top + Inches(1.1), gap - Inches(0.04), Inches(0.5))
            _para(artf, "→", 26, CYAN, bold=True, align=PP_ALIGN.CENTER, first=True)
        x += box_w + gap
    return s


def table_slide():
    s = prs.slides.add_slide(BLANK)
    _bg(s, WHITE)
    _bar(s, 0, 0, Inches(0.25), H, CYAN)
    tb, tf = _box(s, Inches(0.8), Inches(0.4), W - Inches(1.6), Inches(0.9))
    _para(tf, "Comparativa de las tres versiones", 28, NAVY, bold=True, first=True)
    rows, cols = 8, 4
    left, top = Inches(0.8), Inches(1.5)
    width, height = Inches(12.0), Inches(0.62)
    data = [
        ["Criterio", "Pipeline", "Mono-agente", "Multi-agente"],
        ["Nº de agentes (LLMs)", "1 (rol fijo)", "1 (rol amplio)", "3+ (especializados)"],
        ["Toma decisiones", "No", "Limitada", "Por etapa"],
        ["Pasos / etapas", "Fijos", "1 solo paso", "N etapas en cadena"],
        ["Control por etapa", "No", "No", "Sí"],
        ["Velocidad / coste", "Bajo", "Bajo", "Mayor"],
        ["Endpoint", "/translate", "/translate-mono", "/translate-multi"],
        ["Cuándo usar", "Tareas repetitivas", "Tarea única completa", "Tareas complejas dividibles"],
    ]
    for r in range(rows):
        for c in range(cols):
            sh = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, left + c * width / cols, top + r * height, width / cols, height)
            sh.fill.solid()
            sh.fill.fore_color.rgb = NAVY if r == 0 else (LIGHT if r % 2 == 0 else WHITE)
            sh.line.color.rgb = RGBColor(0xD5, 0xDD, 0xE5)
            sh.line.width = Pt(0.75)
            sh.shadow.inherit = False
            tfc = sh.text_frame
            tfc.word_wrap = True
            tfc.margin_left = Inches(0.1)
            tfc.margin_right = Inches(0.1)
            tfc.vertical_anchor = MSO_ANCHOR.MIDDLE
            p = tfc.paragraphs[0]
            p.alignment = PP_ALIGN.LEFT if c == 0 else PP_ALIGN.CENTER
            run = p.add_run()
            run.text = data[r][c]
            run.font.size = Pt(13)
            run.font.name = FONT
            run.font.bold = (r == 0 or c == 0)
            run.font.color.rgb = WHITE if r == 0 else (NAVY if c == 0 else DARK)
    return s


# =========================================================
# 1. PORTADA
# =========================================================
title_slide()

# 2. Objetivo
bullets("Objetivo del ejercicio", [
    "Construir, paso a paso, un traductor tipo DeepL que corre 100% en local.",
    "Entender la evolución de un sistema de IA en tres arquitecturas:",
    ("Pipeline → pasos fijos, sin decisiones", 1),
    ("Mono-agente → un único LLM hace toda la tarea", 1),
    ("Multi-agente → agentes especializados que colaboran en cadena", 1),
    "Aprender a detectar en qué momento conviene usar cada una.",
], kicker="INTRODUCCIÓN")

# 3. Qué vamos a construir
bullets("¿Qué vamos a construir?", [
    "Un traductor de texto entre varios idiomas (es, en, fr, de, pt, it, zh, ja, ko).",
    "Backend: API REST con FastAPI (3 endpoints, uno por arquitectura).",
    "Frontend: interfaz con Streamlit para probarlo.",
    "Motor: Ollama ejecutando el modelo local qwen2.5:7b (sin APIs externas).",
    "Cliente de Ollama propio con HTTPX (sync + async + streaming).",
], kicker="INTRODUCCIÓN")

# 4. Concepto previo
bullets("Concepto previo: pipeline vs. agente", [
    "Pipeline: secuencia de pasos fijos y predecibles. El LLM solo genera texto en un punto.",
    "Agente: sistema con autonomía para decidir, razonar y encadenar acciones.",
    "Regla práctica:",
    ("Si NO toma decisiones y siempre hace lo mismo → pipeline", 1),
    ("Si decide, razona o usa herramientas → agente", 1),
    "Este ejercicio muestra la progresión natural entre ambos extremos.",
], kicker="INTRODUCCIÓN")

# 5. Requisitos
bullets("Requisitos y herramientas", [
    "Python 3.12 + Poetry (gestión de dependencias).",
    "Ollama instalado y modelo descargado:  ollama pull qwen2.5:7b",
    "Librerías: FastAPI, Uvicorn, HTTPX, python-dotenv, Streamlit.",
    "Estructura inicial: src/myowndeepl/backend y src/myowndeepl/frontend.",
    "Configuración central en settings.py (OLLAMA_URL y MODEL).",
], kicker="PREPARACIÓN")

# 6. Estructura
code_slide(
    "Estructura del proyecto",
    """src/myowndeepl/
├── backend/
│   ├── main.py               # FastAPI: endpoints de los 3 modos
│   ├── llm_model.py          # Cliente de Ollama (ChatOllama) + streaming
│   ├── detector_language.py  # Detección de idioma (Ollama + heurístico)
│   ├── traductor.py          # Petición + prompts (traducir/gramática/estilo)
│   ├── settings.py           # OLLAMA_URL y MODEL
│   ├── monoagent.py          # 🔹 Arquitectura mono-agente
│   └── multiagent.py         # 🔹 Arquitectura multi-agente
└── frontend/
    └── main.py               # Streamlit con selector de modo""",
    caption="Los módulos monoagent.py y multiagent.py se añaden en cada versión.",
    kicker="PREPARACIÓN")

# =========================================================
# VERSIÓN 1
# =========================================================
section("Pipeline", "Pasos fijos, sin decisiones ni bucles", "1")

flow_slide(
    "Flujo del pipeline",
    [
        ("Usuario", "envía el texto y los idiomas"),
        ("Detectar idioma", "solo si source = auto"),
        ("Construir prompt", "build_prompt()"),
        ("LLM (Ollama)", "genera la traducción"),
        ("Respuesta", "streaming (SSE)"),
    ],
    kicker="VERSIÓN 1 — PIPELINE")

code_slide(
    "Paso 1 — Detección de idioma",
    """async def detect_language(text: str) -> str:
    prompt = DETECT_PROMPT.format(text=text)
    raw = await agenerate(prompt, temperature=0.0)   # llama a Ollama
    code = raw.strip().lower()[:2]
    if code in LANGUAGES:
        return code
    return _heuristic(text)   # respaldo heurístico""",
    caption="detector_language.py — usa el propio LLM para detectar el idioma.",
    kicker="VERSIÓN 1 — PIPELINE")

code_slide(
    "Paso 2 — Construir el prompt",
    """def build_prompt(text, source, target):
    return f'''You are a professional translator.
Translate the following text from {source} to {target}.

Rules:
- Return ONLY the translated text, no explanations
- Preserve formatting, line breaks, and punctuation

Text to translate:
{text}

Translation:'''""",
    caption="traductor.py — el prompt es el 'contrato' con el LLM.",
    kicker="VERSIÓN 1 — PIPELINE")

code_slide(
    "Paso 3 — Endpoint /translate (streaming)",
    """@app.post("/translate")
async def translate(req: TranslateRequest):
    source = req.source_lang
    if source == "auto":
        source = await detect_language(req.text)

    prompt = build_prompt(req.text, source, req.target_lang)

    async def stream():
        async for token in astream(prompt):
            yield f"data: {json.dumps({'token': token})}\\n\\n"
        yield "data: [DONE]\\n\\n"

    return StreamingResponse(stream(), media_type="text/event-stream")""",
    caption="main.py — siempre los mismos pasos, en el mismo orden.",
    kicker="VERSIÓN 1 — PIPELINE")

bullets("Resultado del pipeline", [
    "Entrada:  'Hola, como estas hoy? Me gusta programar en Python.'",
    "Salida (streaming, token a token):",
    ("Hello, how are you today? I like programming in Python.", 1),
    "Ventajas: simple, rápido y fácil de depurar.",
    "Limitación: no puede adaptarse ni decidir corregir algo por su cuenta.",
], kicker="VERSIÓN 1 — PIPELINE")

# =========================================================
# VERSIÓN 2
# =========================================================
section("Mono-agente", "Un único LLM resuelve toda la tarea", "2")

flow_slide(
    "Flujo del mono-agente",
    [
        ("Input", "texto de entrada"),
        ("Agente único (1 LLM)", "detecta + traduce en un paso"),
        ("Output", "traducción final"),
    ],
    kicker="VERSIÓN 2 — MONO-AGENTE")

code_slide(
    "MonoAgent — un agente, una tarea completa",
    """class MonoAgent:
    name = "Mono-agent traductor"
    description = "Reconoce el idioma y traduce en un único paso."

    def __init__(self, model=None):
        self.llm = ChatOllama(model=model) if model else ChatOllama()

    async def run(self, text, source_lang="auto", target_lang="en"):
        source = source_lang
        if source == "auto":
            source = await detect_language(text)   # el agente decide
        prompt = build_prompt(text, source, target_lang)
        result = await self.llm.ainvoke(prompt)    # UNA sola llamada
        return result["content"]""",
    caption="monoagent.py — encapsula toda la lógica en un solo componente.",
    kicker="VERSIÓN 2 — MONO-AGENTE")

code_slide(
    "Endpoint /translate-mono",
    """@app.post("/translate-mono")
async def translate_mono(req: TranslateRequest):
    agent = MonoAgent()                       # se crea el agente
    translation = await agent.run(
        req.text, req.source_lang, req.target_lang
    )
    return {"mode": "mono-agent", "translation": translation}""",
    caption="main.py — el endpoint solo delega en el agente.",
    kicker="VERSIÓN 2 — MONO-AGENTE")

bullets("Qué cambió respecto al pipeline", [
    "La lógica (detectar + traducir) ahora vive DENTRO de una clase agente.",
    "El endpoint se vuelve trivial: crear agente → llamar run().",
    "El agente es reutilizable desde cualquier parte del código.",
    "Limitación: si la tarea crece (corregir, adaptar tono), el prompt se vuelve gigante.",
], kicker="VERSIÓN 2 — MONO-AGENTE")

# =========================================================
# VERSIÓN 3
# =========================================================
section("Multi-agente", "Agentes especializados que colaboran en cadena", "3")

flow_slide(
    "Flujo del multi-agente",
    [
        ("Input", "texto de entrada"),
        ("Translator Agent", "traduce el texto"),
        ("Grammar Corrector", "corrige gramática"),
        ("Style Refiner", "mejora estilo"),
        ("Final Output", "resultado final"),
    ],
    kicker="VERSIÓN 3 — MULTI-AGENTE")

code_slide(
    "Tres agentes especializados",
    """class TranslatorAgent:      # traduce
    async def run(self, text, source_lang, target_lang):
        if source_lang == "auto":
            source_lang = await detect_language(text)
        return (await self.llm.ainvoke(build_prompt(...)))["content"]

class GrammarCorrector:      # corrige gramática
    async def run(self, text):
        return (await self.llm.ainvoke(build_grammar_prompt(text)))["content"]

class StyleRefiner:          # mejora estilo
    async def run(self, text):
        return (await self.llm.ainvoke(build_style_prompt(text)))["content"]""",
    caption="multiagent.py — cada agente tiene una responsabilidad única.",
    kicker="VERSIÓN 3 — MULTI-AGENTE")

code_slide(
    "El pipeline que los encadena",
    """class MultiAgentPipeline:
    def __init__(self, model=None):
        self.translator = TranslatorAgent(model=model)
        self.grammar    = GrammarCorrector(model=model)
        self.style      = StyleRefiner(model=model)

    async def run(self, text, source_lang="auto", target_lang="en"):
        translated = await self.translator.run(text, source_lang, target_lang)
        corrected  = await self.grammar.run(translated)
        refined    = await self.style.run(corrected)
        return {
            "translator": translated,
            "grammar":    corrected,
            "style":      refined,
            "final":      refined,
        }""",
    caption="Cada agente recibe la salida del anterior y devuelve el resultado de su etapa.",
    kicker="VERSIÓN 3 — MULTI-AGENTE")

bullets("Ejemplo real (es → en)", [
    "Entrada:  'Hola, como estas hoy? Me gusta programar en Python.'",
    ("1. Translator:  Hello, how are you today? I like programming in Python.", 1),
    ("2. Grammar:     Hello, how are you today? I like programming in Python.", 1),
    ("3. Style:       Hello, how are you today? I enjoy programming in Python.", 1),
    "El agente de estilo cambió 'like' → 'enjoy': cada etapa aporta algo distinto.",
], kicker="VERSIÓN 3 — MULTI-AGENTE")

bullets("Ventajas del multi-agente", [
    "Separación de responsabilidades: cada agente hace una sola cosa bien.",
    "Inspeccionable: el endpoint devuelve la salida de cada etapa.",
    "Escalable: añadir/quitar agentes sin tocar los demás.",
    "Cada agente usa su propio prompt específico (traducir / corregir / refinar).",
    "Coste: más llamadas al LLM → más lento y algo más complejo.",
], kicker="VERSIÓN 3 — MULTI-AGENTE")

# =========================================================
# CIERRE
# =========================================================
table_slide()

bullets("Cómo ejecutar y probar", [
    "Backend:  poetry run uvicorn main:app --host localhost --port 8000 --reload",
    "Frontend:  poetry run streamlit run main.py",
    "Endpoints de prueba:",
    ("POST /translate        → pipeline (streaming)", 1),
    ("POST /translate-mono   → mono-agente", 1),
    ("POST /translate-multi  → multi-agente (devuelve cada etapa)", 1),
    ("GET  /health, /languages", 1),
    "La interfaz Streamlit incluye un selector de modo para comparar las tres versiones.",
], kicker="DEMO EN VIVO")

bullets("Lecciones aprendidas", [
    "Un pipeline es el punto de partida correcto para validar la idea.",
    "El mono-agente encapsula la lógica en un componente reutilizable.",
    "El multi-agente aporta control, especialización y trazabilidad por etapa.",
    "Evolución típica: pipeline → mono-agente → multi-agente (según crece la tarea).",
    "Todo corre en local con Ollama: sin costes ni dependencia de APIs externas.",
], kicker="CIERRE")

# Diapositiva final
s = prs.slides.add_slide(BLANK)
_bg(s, NAVY)
_bar(s, 0, Inches(3.0), W, Inches(0.06), CYAN)
tb, tf = _box(s, Inches(0.9), Inches(3.2), W - Inches(1.8), Inches(1.5))
_para(tf, "Pipeline → Mono-agente → Multi-agente", 34, WHITE, bold=True, first=True, space_after=10)
_para(tf, "¡Gracias!  ·  Preguntas y discusión", 20, CYAN, bold=True)

out = "presentacion_arquitecturas_agentes.pptx"
prs.save(out)
print(f"OK -> {out}  ({len(prs.slides.__iter__.__self__._sldIdLst)} diapositivas)")
