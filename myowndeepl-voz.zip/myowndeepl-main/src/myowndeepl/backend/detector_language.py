"""Detección de idioma usando Ollama (completamente local)."""
from llm_model import agenerate
from settings import LANGUAGES

DETECT_PROMPT = """Detect the language of the following text.
Reply with ONLY the 2-letter ISO 639-1 code (for example: es, en, fr, de, pt, it, zh, ja, ko).
Do not add explanations, quotes or punctuation.

Text:
{text}

Language code:"""

# Heurístico de respaldo por si el modelo devuelve algo inesperado.
_COMMON_WORDS = {
    "es": ["el", "la", "los", "las", "de", "que", "y", "hola", "gracias", "cómo", "está"],
    "en": ["the", "and", "hello", "thank", "you", "is", "are", "what", "this"],
    "fr": ["le", "la", "les", "et", "bonjour", "merci", "est", "que", "vous"],
    "de": ["der", "die", "das", "und", "hallo", "danke", "ist", "nicht", "ich"],
    "pt": ["o", "a", "os", "as", "e", "obrigado", "você", "não", "que"],
    "it": ["il", "lo", "la", "e", "ciao", "grazie", "è", "non", "che"],
}


def _heuristic(text: str) -> str:
    tokens = {w.lower() for w in text.split() if w.isalpha()}
    best, best_score = "en", 0
    for code, words in _COMMON_WORDS.items():
        score = len(tokens & set(words))
        if score > best_score:
            best, best_score = code, score
    return best


async def detect_language(text: str) -> str:
    """Devuelve el código ISO 639-1 del idioma detectado."""
    text = (text or "").strip()
    if not text:
        return "en"
    try:
        raw = (await agenerate(DETECT_PROMPT.format(text=text), temperature=0.0))
        code = raw.strip().lower().replace('"', "").replace("'", "")
        # El modelo a veces devuelve "es." o "Spanish"; nos quedamos con las 2 primeras letras
        code = code.strip(".,;:").split()[0][:2]
        if code in LANGUAGES:
            return code
    except Exception:
        pass
    return _heuristic(text)
