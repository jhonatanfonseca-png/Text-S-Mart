"""Modo multi-agente: pipeline de agentes especializados.

Input
  -> Translator Agent   (traduce)
  -> Grammar Corrector  (corrige gramática)
  -> Style Refiner      (mejora estilo)
  -> Final Output
"""
from llm_model import ChatOllama
from detector_language import detect_language
from traductor import build_prompt, build_grammar_prompt, build_style_prompt


class TranslatorAgent:
    name: str = "Translator Agent"
    description: str = "Traduce el texto del idioma de origen al idioma de destino."

    def __init__(self, model: str | None = None):
        self.llm = ChatOllama(model=model) if model else ChatOllama()

    async def run(self, text: str, source_lang: str, target_lang: str) -> str:
        source = source_lang
        if source == "auto":
            source = await detect_language(text)
        result = await self.llm.ainvoke(build_prompt(text, source, target_lang))
        return result["content"]


class GrammarCorrector:
    name: str = "Grammar Corrector"
    description: str = "Corrige errores de gramática, ortografía y puntuación."

    def __init__(self, model: str | None = None):
        self.llm = ChatOllama(model=model) if model else ChatOllama()

    async def run(self, text: str) -> str:
        result = await self.llm.ainvoke(build_grammar_prompt(text))
        return result["content"]


class StyleRefiner:
    name: str = "Style Refiner"
    description: str = "Mejora el estilo para que suene natural."

    def __init__(self, model: str | None = None):
        self.llm = ChatOllama(model=model) if model else ChatOllama()

    async def run(self, text: str) -> str:
        result = await self.llm.ainvoke(build_style_prompt(text))
        return result["content"]


class MultiAgentPipeline:
    """Encadena los tres agentes y devuelve el resultado de cada etapa."""

    def __init__(self, model: str | None = None):
        self.translator = TranslatorAgent(model=model)
        self.grammar = GrammarCorrector(model=model)
        self.style = StyleRefiner(model=model)

    async def run(self, text: str, source_lang: str = "auto", target_lang: str = "en") -> dict:
        translated = await self.translator.run(text, source_lang, target_lang)
        corrected = await self.grammar.run(translated)
        refined = await self.style.run(corrected)
        return {
            "translator": translated,
            "grammar": corrected,
            "style": refined,
            "final": refined,
        }
