from pydantic import BaseModel
from settings import LANGUAGES


class TranslateRequest(BaseModel):
    text: str
    source_lang: str = "auto"
    target_lang: str = "en"


def _lang_name(code: str) -> str:
    return LANGUAGES.get(code, code)


def build_prompt(text: str, source: str, target: str) -> str:
    src_name = "auto-detected" if source == "auto" else _lang_name(source)
    tgt_name = _lang_name(target)
    return f"""You are a professional translator. Translate the following text from {src_name} to {tgt_name}.

Rules:
- Return ONLY the translated text, no explanations, no quotes
- Preserve formatting, line breaks, and punctuation
- Keep proper nouns as-is unless they have a standard translation

Text to translate:
{text}

Translation:"""


def build_grammar_prompt(text: str) -> str:
    return f"""You are a grammar corrector. Fix any grammar, spelling or punctuation mistakes in the following text. Keep the same language and meaning. Return ONLY the corrected text.

Text:
{text}

Corrected text:"""


def build_style_prompt(text: str) -> str:
    return f"""You are a style editor. Improve the style and naturalness of the following text so it reads like a native speaker wrote it. Keep the same language, meaning and structure. Return ONLY the improved text.

Text:
{text}

Improved text:"""
