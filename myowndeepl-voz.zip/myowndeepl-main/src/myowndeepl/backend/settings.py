OLLAMA_URL = "http://localhost:11434"
MODEL = "qwen2.5:7b"

LANGUAGES = {
    "es": "Spanish", "en": "English", "fr": "French",
    "de": "German", "pt": "Portuguese", "it": "Italian",
    "zh": "Chinese", "ja": "Japanese", "ko": "Korean",
}
