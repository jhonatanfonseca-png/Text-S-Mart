from fastapi import FastAPI, File, Form, UploadFile, HTTPException
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import Response
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
import json

from traductor import TranslateRequest, build_prompt
from settings import LANGUAGES, MODEL
from detector_language import detect_language
from llm_model import astream
from monoagent import MonoAgent
from multiagent import MultiAgentPipeline
import voice

app = FastAPI(title="myowndeepl", description="Traductor IA similar a DeepL (local con Ollama)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/detect")
async def detect(req: TranslateRequest):
    """Detecta el idioma de un texto y devuelve el código ISO y el nombre."""
    code = await detect_language(req.text)
    return {"language": code, "name": LANGUAGES.get(code, code)}


@app.get("/languages")
def languages():
    """Lista de idiomas soportados."""
    return LANGUAGES


@app.post("/translate")
async def translate(req: TranslateRequest):
    """Pipeline básico: detectar (si es auto) -> prompt -> LLM -> respuesta (streaming)."""
    source = req.source_lang
    if source == "auto":
        source = await detect_language(req.text)

    prompt = build_prompt(req.text, source, req.target_lang)

    async def stream():
        async for token in astream(prompt):
            yield f"data: {json.dumps({'token': token})}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(stream(), media_type="text/event-stream")


@app.post("/translate-mono")
async def translate_mono(req: TranslateRequest):
    """Modo mono-agente: un único agente hace toda la tarea."""
    agent = MonoAgent()
    translation = await agent.run(req.text, req.source_lang, req.target_lang)
    return {"mode": "mono-agent", "translation": translation}


@app.post("/translate-multi")
async def translate_multi(req: TranslateRequest):
    """Modo multi-agente: traductor -> corrector gramatical -> refinador de estilo."""
    pipeline = MultiAgentPipeline()
    result = await pipeline.run(req.text, req.source_lang, req.target_lang)
    return {"mode": "multi-agent", **result}


@app.post("/transcribe")
async def transcribe(file: UploadFile = File(...), language: str = Form("auto")):
    """Voz -> texto (Whisper local). `language` = código ISO o "auto"."""
    data = await file.read()
    lang = None if language == "auto" else language
    try:
        return await run_in_threadpool(voice.transcribe_bytes, data, lang)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error transcribiendo: {e}")


class SpeakRequest(BaseModel):
    text: str
    lang: str = "en"


@app.post("/speak")
async def speak(req: SpeakRequest):
    """Texto -> voz (mp3)."""
    try:
        audio = await voice.synthesize(req.text, req.lang)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generando voz: {e}")
    return Response(content=audio, media_type="audio/mpeg")


@app.get("/health")
def health():
    return {"status": "ok", "model": MODEL}
