"""Cliente ligero para Ollama usando httpx (sin dependencias extra).

Proporciona:
  - Funciones de bajo nivel: generate (sync), agenerate (async), astream (streaming)
  - Clase ChatOllama: reemplazo sencillo de langchain_ollama.ChatOllama,
    compatible con agentes que esperan invoke()/ainvoke().
"""
import json
import httpx

from settings import OLLAMA_URL, MODEL


def generate(prompt: str, model: str = MODEL, temperature: float = 0.2) -> str:
    """Llamada síncrona a /api/generate. Devuelve el texto generado."""
    with httpx.Client(timeout=180) as client:
        resp = client.post(
            f"{OLLAMA_URL}/api/generate",
            json={
                "model": model,
                "prompt": prompt,
                "stream": False,
                "options": {"temperature": temperature},
            },
        )
        resp.raise_for_status()
        return resp.json().get("response", "")


async def agenerate(prompt: str, model: str = MODEL, temperature: float = 0.2) -> str:
    """Llamada asíncrona a /api/generate. Devuelve el texto generado."""
    async with httpx.AsyncClient(timeout=180) as client:
        resp = await client.post(
            f"{OLLAMA_URL}/api/generate",
            json={
                "model": model,
                "prompt": prompt,
                "stream": False,
                "options": {"temperature": temperature},
            },
        )
        resp.raise_for_status()
        return resp.json().get("response", "")


async def astream(prompt: str, model: str = MODEL, temperature: float = 0.2):
    """Generador asíncrono que produce tokens (streaming) para SSE."""
    async with httpx.AsyncClient(timeout=180) as client:
        async with client.stream(
            "POST",
            f"{OLLAMA_URL}/api/generate",
            json={
                "model": model,
                "prompt": prompt,
                "stream": True,
                "options": {"temperature": temperature},
            },
        ) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if not line:
                    continue
                data = json.loads(line)
                token = data.get("response", "")
                if token:
                    yield token
                if data.get("done"):
                    break


class ChatOllama:
    """Drop-in replacement para langchain_ollama.ChatOllama."""

    def __init__(self, model: str = MODEL, base_url: str = OLLAMA_URL):
        self.model = model
        self.base_url = base_url.rstrip("/")

    def invoke(self, prompt: str) -> dict:
        """Imita ChatOpenAI.invoke(): devuelve {"content": ...}."""
        return {"content": generate(prompt, model=self.model)}

    async def ainvoke(self, prompt: str) -> dict:
        """Versión asíncrona."""
        return {"content": await agenerate(prompt, model=self.model)}
