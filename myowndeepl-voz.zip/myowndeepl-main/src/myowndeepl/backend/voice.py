"""Voz: speech-to-text (faster-whisper, local) y text-to-speech (edge-tts)."""
import tempfile
import os

import edge_tts

# Modelo de Whisper: "tiny", "base", "small", "medium"... (más grande = más preciso y más lento)
WHISPER_MODEL = "base"

# Voz neuronal por idioma para la salida hablada
VOICES = {
    "es": "es-CO-SalomeNeural",
    "en": "en-US-JennyNeural",
    "fr": "fr-FR-DeniseNeural",
    "de": "de-DE-KatjaNeural",
    "pt": "pt-BR-FranciscaNeural",
    "it": "it-IT-ElsaNeural",
    "zh": "zh-CN-XiaoxiaoNeural",
    "ja": "ja-JP-NanamiNeural",
    "ko": "ko-KR-SunHiNeural",
}

_model = None


def _get_model():
    # Se carga la primera vez que se usa (descarga el modelo una sola vez)
    global _model
    if _model is None:
        from faster_whisper import WhisperModel
        _model = WhisperModel(WHISPER_MODEL, device="cpu", compute_type="int8")
    return _model


def transcribe_file(path: str, language: str | None = None) -> dict:
    segments, info = _get_model().transcribe(path, language=language, vad_filter=True)
    text = " ".join(s.text.strip() for s in segments).strip()
    return {"text": text, "language": info.language}


def transcribe_bytes(data: bytes, language: str | None = None) -> dict:
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        f.write(data)
        path = f.name
    try:
        return transcribe_file(path, language)
    finally:
        os.remove(path)


async def synthesize(text: str, lang: str) -> bytes:
    voice = VOICES.get(lang, VOICES["en"])
    audio = b""
    async for chunk in edge_tts.Communicate(text, voice).stream():
        if chunk["type"] == "audio":
            audio += chunk["data"]
    return audio
