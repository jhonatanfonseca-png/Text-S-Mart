"""Modo mono-agente: un único agente (LLM) realiza toda la tarea.

Input -> (detección de idioma si es "auto") -> prompt -> LLM -> Output
"""
from llm_model import ChatOllama
from detector_language import detect_language
from traductor import build_prompt


class MonoAgent:
    """Un único modelo que reconoce el idioma y traduce en un solo paso."""

    name: str = "Mono-agent traductor"
    description: str = "Reconoce el idioma de origen y traduce a otro idioma en un único paso."

    def __init__(self, model: str | None = None):
        self.llm = ChatOllama(model=model) if model else ChatOllama()

    async def run(self, text: str, source_lang: str = "auto", target_lang: str = "en") -> str:
        source = source_lang
        if source == "auto":
            source = await detect_language(text)
        prompt = build_prompt(text, source, target_lang)
        result = await self.llm.ainvoke(prompt)
        return result["content"]
