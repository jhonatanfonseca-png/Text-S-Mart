import streamlit as st
import requests
import json

API = "http://localhost:8000"

st.set_page_config(layout="wide")
st.title("Traductor IA / DeepL like app")
st.caption("Demo pipeline · mono-agente · multi-agente con Ollama (local)")

LANGS = {
    "auto": "Detectar idioma",
    "es": "Español",
    "en": "Inglés",
    "fr": "Francés",
    "de": "Alemán",
    "pt": "Portugués",
    "it": "Italiano",
}
REAL_LANGS = list(LANGS.keys())[1:]  # idiomas reales (sin "auto")

# ---------- estado ----------
if "src_lang" not in st.session_state:
    st.session_state.src_lang = "auto"
if "tgt_lang" not in st.session_state:
    st.session_state.tgt_lang = "en"
if "result" not in st.session_state:
    st.session_state.result = None
if "pending_src" not in st.session_state:
    st.session_state.pending_src = None
if "text_input" not in st.session_state:
    st.session_state.text_input = ""
if "last_audio_id" not in st.session_state:
    st.session_state.last_audio_id = None


def detect_language(text: str):
    """Detecta el idioma llamando al endpoint /detect."""
    try:
        r = requests.post(
            f"{API}/detect",
            json={"text": text, "source_lang": "auto", "target_lang": "en"},
            timeout=120,
        )
        return r.json()["language"].lower()
    except Exception as e:
        st.error(f"Error detectando el idioma: {e}")
        return None


# ---------- 1 · selector de arquitectura (arriba) ----------
mode = st.radio(
    "1 · Elige la arquitectura",
    ["Pipeline", "Mono-agente", "Multi-agente"],
    horizontal=True,
)

def current_translation():
    """Texto de la última traducción (para leerla en voz alta)."""
    r = st.session_state.result
    if not r:
        return ""
    return r["final"] if r["kind"] == "multi" else r["translation"]


# Aplicar el idioma detectado ANTES de crear el widget selectbox de origen.
if st.session_state.pending_src in REAL_LANGS:
    st.session_state.src_lang = st.session_state.pending_src
    st.session_state.pending_src = None

col1, col2 = st.columns(2)

with col1:
    st.subheader("Entrada")

    if mode == "Pipeline":
        # Pipeline: OBLIGATORIO elegir el idioma de origen (sin "auto")
        if st.session_state.src_lang not in REAL_LANGS:
            st.session_state.src_lang = REAL_LANGS[0]
        src_options = REAL_LANGS
        src_label = "Idioma origen (elige el idioma)"
        src_help = "En modo Pipeline debes elegir el idioma de origen manualmente."
        src_disabled = False
    else:
        # Mono / Multi: se detecta automáticamente y se actualiza el select
        if st.session_state.src_lang not in ["auto"] + REAL_LANGS:
            st.session_state.src_lang = "auto"
        src_options = ["auto"] + REAL_LANGS
        src_label = "Idioma origen (auto-detección)"
        src_help = "El idioma se detecta automáticamente al traducir."
        src_disabled = True

    src_lang = st.selectbox(
        src_label,
        src_options,
        format_func=lambda x: LANGS[x],
        key="src_lang",
        help=src_help,
        disabled=src_disabled,
    )

    # --- micrófono: voz -> texto ---
    audio = st.audio_input("🎤 Habla aquí (graba y se transcribe solo)")
    if audio is not None and audio.file_id != st.session_state.last_audio_id:
        st.session_state.last_audio_id = audio.file_id
        with st.spinner("Transcribiendo..."):
            try:
                r = requests.post(
                    f"{API}/transcribe",
                    files={"file": ("audio.wav", audio.getvalue(), "audio/wav")},
                    data={"language": st.session_state.src_lang if mode == "Pipeline" else "auto"},
                    timeout=300,
                )
                r.raise_for_status()
                st.session_state.text_input = r.json()["text"]
                st.rerun()
            except Exception as e:
                st.error(f"Error transcribiendo: {e}")

    text = st.text_area("Texto", height=250, key="text_input")
    traducir = st.button("Traducir", type="primary")

with col2:
    st.subheader("Salida")
    tgt_lang = st.selectbox(
        "Idioma destino",
        REAL_LANGS,
        format_func=lambda x: LANGS[x],
        key="tgt_lang",
    )

    output_box = st.empty()  # para el streaming del pipeline

    # resultado guardado (mono / multi)
    result = st.session_state.result
    if result:
        if result["kind"] == "pipeline":
            st.text_area("Traducción (pipeline)", value=result["translation"], height=250)
        elif result["kind"] == "mono":
            st.text_area("Traducción (mono-agente)", value=result["translation"], height=250)
        elif result["kind"] == "multi":
            st.markdown("**Etapas del pipeline multi-agente:**")
            st.text_area("1 · Translator Agent", value=result["translator"], height=90)
            st.text_area("2 · Grammar Corrector", value=result["grammar"], height=90)
            st.text_area("3 · Style Refiner", value=result["style"], height=90)
            st.success("✅ Resultado final")
            st.text_area("Final", value=result["final"], height=90)

    # --- voz: texto -> audio ---
    if current_translation():
        if st.button("🔊 Escuchar traducción"):
            with st.spinner("Generando voz..."):
                try:
                    r = requests.post(
                        f"{API}/speak",
                        json={"text": current_translation(), "lang": st.session_state.tgt_lang},
                        timeout=120,
                    )
                    r.raise_for_status()
                    st.audio(r.content, format="audio/mpeg", autoplay=True)
                except Exception as e:
                    st.error(f"Error generando voz: {e}")


# ---------- lógica de traducción ----------
if traducir and text.strip():
    try:
        if mode == "Pipeline":
            output_box.info("Traduciendo...")
            acc = ""
            response = requests.post(
                f"{API}/translate",
                json={
                    "text": text,
                    "source_lang": src_lang,
                    "target_lang": tgt_lang,
                },
                stream=True,
                timeout=180,
            )
            for line in response.iter_lines():
                if line:
                    line = line.decode()
                    if line.startswith("data: "):
                        payload = line[6:]
                        if payload == "[DONE]":
                            break
                        acc += json.loads(payload)["token"]
                        output_box.text_area("Traducción (pipeline)", value=acc, height=250)
            st.session_state.result = {"kind": "pipeline", "translation": acc}
            st.rerun()

        elif mode == "Mono-agente":
            detected = detect_language(text)
            if detected in REAL_LANGS:
                st.session_state.pending_src = detected  # se aplica en la siguiente ejecución
            res = requests.post(
                f"{API}/translate-mono",
                json={
                    "text": text,
                    "source_lang": detected if detected in REAL_LANGS else "auto",
                    "target_lang": tgt_lang,
                },
                timeout=180,
            )
            data = res.json()
            st.session_state.result = {"kind": "mono", "translation": data["translation"]}
            st.rerun()

        else:  # Multi-agente
            detected = detect_language(text)
            if detected in REAL_LANGS:
                st.session_state.pending_src = detected  # se aplica en la siguiente ejecución
            res = requests.post(
                f"{API}/translate-multi",
                json={
                    "text": text,
                    "source_lang": detected if detected in REAL_LANGS else "auto",
                    "target_lang": tgt_lang,
                },
                timeout=300,
            )
            data = res.json()
            st.session_state.result = {
                "kind": "multi",
                "translator": data["translator"],
                "grammar": data["grammar"],
                "style": data["style"],
                "final": data["final"],
            }
            st.rerun()

    except Exception as e:
        st.error(f"Error: {e}")
