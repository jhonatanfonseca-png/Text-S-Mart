# Arquitecturas de Agentes de IA

## Pipeline · Mono-agente · Multi-agente

**Proyecto de referencia:** `myowndeepl` — un traductor tipo DeepL que corre 100% en local con [Ollama](https://ollama.com).

---

## 1. ¿Qué es un "agente" de IA?

Un **agente** es un sistema que usa un modelo de lenguaje (LLM) para cumplir una tarea. La diferencia entre una aplicación "normal" y una de "agentes" está en **cuánta autonomía** tiene el sistema:

| Grado de autonomía | Características | Ejemplo en este proyecto |
|---|---|---|
| **Pipeline** (sin agente) | Pasos fijos y predecibles. No decide, no usa herramientas, no repite. | Traducción directa (`/translate`) |
| **Mono-agente** | Un solo LLM que razona y ejecuta toda la tarea en un paso. | Un agente traduce (`/translate-mono`) |
| **Multi-agente** | Varios agentes especializados que se pasan el trabajo en cadena. | Traductor → Gramática → Estilo (`/translate-multi`) |

> 📌 **Regla práctica:** si el sistema **no toma decisiones** y siempre hace lo mismo en el mismo orden, es un *pipeline*. Si **decide, razona o usa herramientas**, estamos hablando de *agentes*.

---

## 2. Arquitectura 1 — Pipeline (aplicación básica)

### Definición
Una secuencia de pasos **fijos y deterministas**. El LLM solo genera texto en un punto concreto del flujo. No hay decisiones, ni bucles, ni herramientas.

### Diagrama de flujo

```
 usuario ──► detectar idioma ──► construir prompt ──► LLM ──► respuesta
             (si source=auto)      (build_prompt)     (Ollama)
```

### Código en el proyecto

`backend/main.py` → endpoint `POST /translate`

```python
@app.post("/translate")
async def translate(req: TranslateRequest):
    source = req.source_lang
    if source == "auto":
        source = await detect_language(req.text)   # paso 1: detectar

    prompt = build_prompt(req.text, source, req.target_lang)  # paso 2: prompt

    async def stream():
        async for token in astream(prompt):         # paso 3: LLM (streaming)
            yield f"data: {json.dumps({'token': token})}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(stream(), media_type="text/event-stream")
```

### Características
- ✅ Simple, rápido y fácil de depurar.
- ✅ Siempre el mismo orden de pasos.
- ❌ No puede adaptarse: si el texto viene mal formateado, no "decide" corregirlo.
- ❌ Un solo LLM hace todo el trabajo cognitivo.

### ¿Cuándo usarlo?
Tareas bien definidas y repetitivas: traducir, resumir, clasificar, extraer datos de un texto.

---

## 3. Arquitectura 2 — Mono-agente

### Definición
Un **único agente** (un solo LLM) recibe el objetivo completo y lo resuelve de principio a fin. Internamente razona y encadena lo necesario (aquí: detectar idioma + traducir) sin que nadie se lo ordene paso a paso.

### Diagrama de flujo

```
 Input ──► ┌──────────────────────────┐ ──► Output
           │  AGENTE ÚNICO (1 LLM)    │
           │  detecta + traduce       │
           └──────────────────────────┘
```

### Código en el proyecto

`backend/monoagent.py` → clase `MonoAgent` (endpoint `POST /translate-mono`)

```python
class MonoAgent:
    name = "Mono-agent traductor"
    description = "Reconoce el idioma y traduce en un único paso."

    def __init__(self, model=None):
        self.llm = ChatOllama(model=model) if model else ChatOllama()

    async def run(self, text, source_lang="auto", target_lang="en"):
        source = source_lang
        if source == "auto":
            source = await detect_language(text)      # el agente decide/detecta
        prompt = build_prompt(text, source, target_lang)
        result = await self.llm.ainvoke(prompt)       # una sola llamada al LLM
        return result["content"]
```

### Características
- ✅ Encapsula la tarea completa en un solo componente reutilizable.
- ✅ El LLM tiene "libertad" para resolver la tarea completa.
- ❌ Si la tarea crece (corregir, adaptar tono, etc.), el prompt se vuelve gigante y difícil de controlar.
- ❌ Un solo modelo = un solo punto de fallo y menos control por etapa.

### ¿Cuándo usarlo?
Tareas que un solo modelo puede resolver con calidad aceptable y que no necesitan inspección intermedia.

---

## 4. Arquitectura 3 — Multi-agente

### Definición
Varios agentes **especializados**, cada uno con una responsabilidad única, que se pasan el resultado en cadena. Cada etapa es independiente, se puede inspeccionar y mejorar por separado.

### Diagrama de flujo

```
 Input
   │
   ▼
┌──────────────────┐
│ Translator Agent │  traduce el texto
└──────────────────┘
   │  (texto traducido)
   ▼
┌──────────────────┐
│ Grammar Corrector│  corrige gramática/ortografía
└──────────────────┘
   │  (texto corregido)
   ▼
┌──────────────────┐
│  Style Refiner   │  mejora naturalidad/estilo
└──────────────────┘
   │
   ▼
 Final Output
```

### Código en el proyecto

`backend/multiagent.py` → `MultiAgentPipeline` (endpoint `POST /translate-multi`)

```python
class TranslatorAgent:
    name = "Translator Agent"
    async def run(self, text, source_lang, target_lang):
        if source_lang == "auto":
            source_lang = await detect_language(text)
        return (await self.llm.ainvoke(build_prompt(text, source_lang, target_lang)))["content"]

class GrammarCorrector:
    name = "Grammar Corrector"
    async def run(self, text):
        return (await self.llm.ainvoke(build_grammar_prompt(text)))["content"]

class StyleRefiner:
    name = "Style Refiner"
    async def run(self, text):
        return (await self.llm.ainvoke(build_style_prompt(text)))["content"]

class MultiAgentPipeline:
    async def run(self, text, source_lang="auto", target_lang="en"):
        translated = await self.translator.run(text, source_lang, target_lang)
        corrected  = await self.grammar.run(translated)
        refined    = await self.style.run(corrected)
        return {
            "translator": translated,
            "grammar": corrected,
            "style": refined,
            "final": refined,
        }
```

> 🔍 **Ejemplo real** (entrada: *"Hola, como estas hoy? Me gusta programar en Python."* → inglés):
>
> | Etapa | Agente | Salida |
> |---|---|---|
> | 1 | Translator | `Hello, how are you today? I like programming in Python.` |
> | 2 | Grammar | `Hello, how are you today? I like programming in Python.` |
> | 3 | Style | `Hello, how are you today? I **enjoy** programming in Python.` |

Fíjate cómo el agente de estilo cambió `like` → `enjoy` para sonar más natural. Cada etapa aporta algo distinto.

### Características
- ✅ **Separación de responsabilidades**: cada agente hace una sola cosa bien.
- ✅ **Inspeccionable**: puedes ver la salida de cada etapa (el endpoint la devuelve).
- ✅ **Escalable**: añadir/quitar agentes sin tocar los demás.
- ✅ Cada agente usa su propio prompt específico.
- ❌ Más lento y costoso (varias llamadas al LLM).
- ❌ Más código y más puntos de fallo.

### ¿Cuándo usarlo?
Tareas complejas que se benefician de dividirse en etapas verificables: traducir + corregir + refinar, investigar + redactar + revisar, etc.

---

## 5. Tabla comparativa

| Criterio | Pipeline | Mono-agente | Multi-agente |
|---|---|---|---|
| Nº de LLMs / agentes | 1 (rol fijo) | 1 (rol amplio) | 3+ (roles especializados) |
| Toma decisiones | ❌ No | ✅ Limitada | ✅ Por etapa |
| Nº de pasos | Fijos | 1 paso | N pasos en cadena |
| Herramientas / bucles | ❌ | ❌ | Posible (futuro) |
| Control por etapa | ❌ | ❌ | ✅ |
| Velocidad / coste | ⚡ Bajo | ⚡ Bajo | 🐢 Mayor |
| Complejidad de código | Baja | Media | Alta |
| Endpoint | `/translate` | `/translate-mono` | `/translate-multi` |

---

## 6. Mapa de archivos del proyecto

```
src/myowndeepl/
├── backend/
│   ├── main.py               # FastAPI: endpoints de los 3 modos
│   ├── llm_model.py          # Cliente de Ollama (ChatOllama) + streaming
│   ├── detector_language.py  # Detección de idioma (Ollama + heurístico)
│   ├── traductor.py          # Modelo de petición + prompts (traducir/gramática/estilo)
│   ├── monoagent.py          # 🔹 Arquitectura mono-agente
│   ├── multiagent.py         # 🔹 Arquitectura multi-agente
│   └── settings.py           # OLLAMA_URL y MODEL
└── frontend/
    └── main.py               # Streamlit con selector de modo
```

---

## 7. Cómo elegir la arquitectura correcta

1. **¿La tarea tiene pasos fijos y no necesita decisiones?** → **Pipeline**.
2. **¿Un solo LLM puede hacerlo todo con buena calidad?** → **Mono-agente**.
3. **¿Necesitas dividir en etapas, inspeccionar cada una, o mezclar especialistas?** → **Multi-agente**.

> 💡 **Evolución típica de un proyecto:** empiezas con un *pipeline* para validar la idea → lo conviertes en *mono-agente* al encapsular la lógica → y lo escalas a *multi-agente* cuando la tarea crece y necesitas control y especialización por etapa.
