## 🌍 AI Translator API (DeepL-like) myowndeepl

Una API de traducción inteligente impulsada por modelos de lenguaje (LLMs), diseñada para demostrar cómo construir sistemas mono-agente y multi-agente para procesamiento de lenguaje natural.

🚀 Descripción

Este proyecto implementa un traductor similar a DeepL utilizando modelos locales (Ollama), capaz de:

- 🌐 Traducir texto entre múltiples idiomas
- ✍️ Corregir gramática y mejorar estilo
- 🧠 Aplicar pipelines de agentes (multi-agent systems)
- ⚡ Ejecutarse completamente en local (sin APIs externas)

🧩 Arquitectura

El sistema soporta tres modos:

![Texto alternativo](agentes.png)

🔹 Aplicación básica pipeline

Pipeline: el LLM solo genera texto en pasos predefinidos. No hay decisiones, no hay bucle, no hay herramientas.

`usuario → detectar idioma → prompt → LLM → respuesta`

Siempre los mismos pasos en el mismo orden.

🔹 Mono-agente

Un único modelo realiza toda la tarea:

`Input → LLM → Output`

🔹 Multi-agente

Pipeline de agentes especializados:

```
Input
  ↓
Translator Agent
  ↓
Grammar Corrector
  ↓
Style Refiner
  ↓
Final Output
```

🛠️ Tecnologías

- ⚡ FastAPI — API REST
- 🧠 Ollama — LLMs locales (modelo por defecto: `qwen2.5:7b`)
- 🔗 HTTPX — cliente async
- 📦 Poetry — gestión de dependencias
- 🎈 Streamlit — frontend

## 🚀 Puesta en marcha

Requisitos: [Ollama](https://ollama.com) instalado y un modelo descargado, por ejemplo:

```bash
ollama pull qwen2.5:7b
```

Instalar dependencias (crea el entorno virtual la primera vez):

```bash
poetry install
```

### Correr el backend

```bash
cd src/myowndeepl/backend
poetry run uvicorn main:app --host localhost --port 8000 --reload
```

### Correr el frontend

```bash
cd src/myowndeepl/frontend
poetry run streamlit run main.py
```

Abre http://localhost:8501

## 🔌 Endpoints de la API

| Método | Ruta              | Descripción                                              |
|--------|-------------------|----------------------------------------------------------|
| POST   | `/detect`         | Detecta el idioma de un texto                            |
| GET    | `/languages`      | Lista de idiomas soportados                              |
| POST   | `/translate`      | Pipeline básico (streaming SSE)                          |
| POST   | `/translate-mono` | Mono-agente: un LLM hace toda la tarea                   |
| POST   | `/translate-multi`| Multi-agente: traductor → gramática → estilo             |
| GET    | `/health`         | Estado del servicio y modelo en uso                      |

Ejemplos:

```bash
# Detectar idioma
curl -X POST http://localhost:8000/detect \
  -H "Content-Type: application/json" \
  -d '{"text":"Hola, como estas?"}'

# Traducir (streaming)
curl -X POST http://localhost:8000/translate \
  -H "Content-Type: application/json" \
  -d '{"text":"Hola, como estas?","source_lang":"auto","target_lang":"en"}'

# Mono-agente
curl -X POST http://localhost:8000/translate-mono \
  -H "Content-Type: application/json" \
  -d '{"text":"Hola, como estas?","source_lang":"auto","target_lang":"en"}'

# Multi-agente
curl -X POST http://localhost:8000/translate-multi \
  -H "Content-Type: application/json" \
  -d '{"text":"Hola, como estas?","source_lang":"auto","target_lang":"en"}'
```

## ⚙️ Configuración

Edita `src/myowndeepl/backend/settings.py` para cambiar el modelo o la URL de Ollama:

```python
OLLAMA_URL = "http://localhost:11434"
MODEL = "qwen2.5:7b"
```
